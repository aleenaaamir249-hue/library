"""
Library Book Reservation Portal
===============================
A console-based portal where members can search the catalogue and reserve
books, and librarians (admins) can manage the catalogue and see reports.

Storage (persistent, created automatically on first run):
    data/books.csv          - catalogue of books            (CSV)
    data/users.json         - member / admin accounts       (JSON)
    data/reservations.csv   - reservations and waitlist     (CSV)

Run the interactive portal:   python library_portal.py
"""

import csv
import hashlib
import json
import os
from datetime import date

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
DATA_DIR = "data"
MAX_ACTIVE_RESERVATIONS = 3          # per member

BOOK_FIELDS = ["book_id", "title", "author", "category", "copies_total", "copies_available"]
RES_FIELDS = ["res_id", "username", "book_id", "date", "status"]

# Reservation statuses
ACTIVE = "ACTIVE"            # a copy is being held for the member
WAITLISTED = "WAITLISTED"    # no copy free, member is queued
CANCELLED = "CANCELLED"
COLLECTED = "COLLECTED"      # member picked the book up

SAMPLE_BOOKS = [
    ["B001", "Python Crash Course", "Eric Matthes", "Programming", 3, 3],
    ["B002", "Automate the Boring Stuff", "Al Sweigart", "Programming", 2, 2],
    ["B003", "Introduction to Algorithms", "Thomas Cormen", "Computer Science", 2, 2],
    ["B004", "Clean Code", "Robert C. Martin", "Software Engineering", 1, 1],
    ["B005", "Discrete Mathematics", "Kenneth Rosen", "Mathematics", 2, 2],
    ["B006", "Data Science from Scratch", "Joel Grus", "Data Science", 1, 1],
]


# --------------------------------------------------------------------------
# Paths and low-level file helpers
# --------------------------------------------------------------------------
def set_data_dir(path):
    """Change the folder used for all data files (handy for testing)."""
    global DATA_DIR
    DATA_DIR = path


def _path(name):
    """Return the full path of a data file inside DATA_DIR."""
    return os.path.join(DATA_DIR, name)


def _hash_password(password, salt):
    """Return a salted SHA-256 hex digest of the password."""
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()


def _read_csv(filename, fields):
    """
    Read a CSV file into a list of dicts.
    A missing file is created with just a header; permission errors and
    malformed files are reported and an empty list is returned.
    """
    path = _path(filename)
    rows = []
    try:
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                rows.append(row)
    except FileNotFoundError:
        print(f"[info] {filename} not found - creating a new one.")
        _write_csv(filename, fields, [])
    except PermissionError:
        print(f"[error] No permission to read {filename}.")
    except (csv.Error, UnicodeDecodeError) as err:
        print(f"[error] {filename} is corrupted ({err}). Starting with no records.")
    return rows


def _write_csv(filename, fields, rows):
    """Write a list of dicts to a CSV file. Returns True on success."""
    ok = False
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(_path(filename), "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
        ok = True
    except PermissionError:
        print(f"[error] No permission to write {filename}.")
    except OSError as err:
        print(f"[error] Could not write {filename}: {err}")
    finally:
        if not ok:
            print(f"[warning] Changes to {filename} were NOT saved.")
    return ok


# --------------------------------------------------------------------------
# Loading / saving the three data stores
# --------------------------------------------------------------------------
def load_books():
    """Return the catalogue as a list of dicts (numbers converted to int)."""
    books = _read_csv("books.csv", BOOK_FIELDS)
    clean = []
    for b in books:
        try:
            b["copies_total"] = int(b["copies_total"])
            b["copies_available"] = int(b["copies_available"])
            clean.append(b)
        except (ValueError, KeyError, TypeError):
            print(f"[warning] Skipping malformed book row: {b}")
    return clean


def save_books(books):
    """Persist the catalogue."""
    return _write_csv("books.csv", BOOK_FIELDS, books)


def load_reservations():
    """Return all reservations as a list of dicts."""
    return _read_csv("reservations.csv", RES_FIELDS)


def save_reservations(reservations):
    """Persist all reservations."""
    return _write_csv("reservations.csv", RES_FIELDS, reservations)


def load_users():
    """Return the users dict {username: {...}} from users.json."""
    try:
        with open(_path("users.json"), encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print("[info] users.json not found - creating a new one.")
    except PermissionError:
        print("[error] No permission to read users.json.")
    except json.JSONDecodeError as err:
        print(f"[error] users.json is corrupted ({err}). Starting with no users.")
    return {}


def save_users(users):
    """Persist the users dict."""
    ok = False
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(_path("users.json"), "w", encoding="utf-8") as f:
            json.dump(users, f, indent=2)
        ok = True
    except PermissionError:
        print("[error] No permission to write users.json.")
    except OSError as err:
        print(f"[error] Could not write users.json: {err}")
    finally:
        if not ok:
            print("[warning] Changes to users.json were NOT saved.")
    return ok


def initialise_data():
    """
    Called on startup. Makes sure all data files exist: seeds the catalogue
    with sample books and creates a default admin account when needed.
    """
    if not os.path.exists(_path("books.csv")):
        rows = [dict(zip(BOOK_FIELDS, b)) for b in SAMPLE_BOOKS]
        save_books(rows)
    if not os.path.exists(_path("reservations.csv")):
        save_reservations([])
    users = load_users()
    if "admin" not in users:
        salt = os.urandom(8).hex()
        users["admin"] = {
            "name": "Head Librarian",
            "role": "admin",
            "salt": salt,
            "password_hash": _hash_password("admin123", salt),
        }
        save_users(users)
    return users


# --------------------------------------------------------------------------
# Input helpers (all validation lives here)
# --------------------------------------------------------------------------
def read_text(prompt, allow_empty=False):
    """Ask for a string until a non-empty one is given."""
    while True:
        value = input(prompt).strip()
        if value or allow_empty:
            return value
        print("  Input cannot be empty. Try again.")


def read_int(prompt, low=None, high=None):
    """Ask for an integer (optionally within [low, high]) until valid."""
    while True:
        raw = input(prompt).strip()
        try:
            value = int(raw)
        except ValueError:
            print(f"  '{raw}' is not a whole number. Try again.")
            continue
        if (low is not None and value < low) or (high is not None and value > high):
            print(f"  Please enter a number between {low} and {high}.")
            continue
        return value


# --------------------------------------------------------------------------
# Accounts
# --------------------------------------------------------------------------
def register_user(username, name, password, users):
    """
    Create a new member account.
    Returns (True, message) on success or (False, reason) on failure.
    """
    username = username.strip().lower()
    if not username.isalnum():
        return False, "Username must contain only letters and digits."
    if username in users:
        return False, "That username is already taken."
    if len(password) < 4:
        return False, "Password must be at least 4 characters."
    salt = os.urandom(8).hex()
    users[username] = {
        "name": name.strip(),
        "role": "member",
        "salt": salt,
        "password_hash": _hash_password(password, salt),
    }
    save_users(users)
    return True, f"Account '{username}' created."


def user_login(username, password, users):
    """
    Check credentials.
    Returns the username (lower-case) on success, otherwise None.
    """
    username = username.strip().lower()
    record = users.get(username)
    if record is None:
        return None
    if _hash_password(password, record["salt"]) == record["password_hash"]:
        return username
    return None


# --------------------------------------------------------------------------
# Catalogue management and search
# --------------------------------------------------------------------------
def _next_id(rows, key, prefix, width):
    """Generate the next id such as B007 or R0012."""
    highest = 0
    for r in rows:
        try:
            highest = max(highest, int(r[key][len(prefix):]))
        except (ValueError, IndexError, KeyError):
            continue
    return f"{prefix}{highest + 1:0{width}d}"


def add_record(books, title, author, category, copies):
    """
    Add a new book to the catalogue and save it.
    Returns (True, new_book) or (False, reason).
    """
    try:
        copies = int(copies)
    except (ValueError, TypeError):
        return False, "Number of copies must be a whole number."
    if copies < 1:
        return False, "A book needs at least 1 copy."
    if not title.strip() or not author.strip():
        return False, "Title and author are required."
    for b in books:                       # reject exact duplicates
        if b["title"].lower() == title.strip().lower() and \
           b["author"].lower() == author.strip().lower():
            return False, "This book already exists in the catalogue."
    book = {
        "book_id": _next_id(books, "book_id", "B", 3),
        "title": title.strip(),
        "author": author.strip(),
        "category": category.strip() or "General",
        "copies_total": copies,
        "copies_available": copies,
    }
    books.append(book)
    save_books(books)
    return True, book


def search_record(books, keyword="", category=""):
    """
    Return books whose title, author or id contains `keyword`
    (case-insensitive) and, if given, whose category matches `category`.
    """
    keyword = keyword.strip().lower()
    category = category.strip().lower()
    results = []
    for b in books:
        haystack = f"{b['book_id']} {b['title']} {b['author']}".lower()
        if keyword in haystack and (not category or b["category"].lower() == category):
            results.append(b)
    return results


def find_book(books, book_id):
    """Return the book dict with this id, or None."""
    for b in books:
        if b["book_id"].lower() == book_id.strip().lower():
            return b
    return None


def display_books(books):
    """Print a list of books as a neat table."""
    if not books:
        print("  No matching books found.")
        return
    print(f"  {'ID':<6}{'Title':<30}{'Author':<20}{'Category':<22}{'Avail':>7}")
    print("  " + "-" * 85)
    for b in books:
        avail = f"{b['copies_available']}/{b['copies_total']}"
        print(f"  {b['book_id']:<6}{b['title'][:28]:<30}{b['author'][:18]:<20}"
              f"{b['category'][:20]:<22}{avail:>7}")


# --------------------------------------------------------------------------
# Reservations
# --------------------------------------------------------------------------
def member_reservations(reservations, username, statuses=(ACTIVE, WAITLISTED)):
    """Return this member's reservations that have one of the given statuses."""
    return [r for r in reservations
            if r["username"] == username and r["status"] in statuses]


def reserve_book(username, book_id, books, reservations):
    """
    Reserve a book for a member.
    * If a copy is free the reservation is ACTIVE and a copy is held.
    * If no copy is free the member joins the WAITLIST.
    Returns (True, message) or (False, reason).
    """
    book = find_book(books, book_id)
    if book is None:
        return False, f"No book with id '{book_id}'."
    current = member_reservations(reservations, username)
    if len(current) >= MAX_ACTIVE_RESERVATIONS:
        return False, f"Limit reached: max {MAX_ACTIVE_RESERVATIONS} active reservations."
    for r in current:
        if r["book_id"] == book["book_id"]:
            return False, "You already have a reservation for this book."

    res_id = _next_id(reservations, "res_id", "R", 4)
    if book["copies_available"] > 0:
        book["copies_available"] -= 1
        status = ACTIVE
        msg = f"Reserved '{book['title']}'. Reservation {res_id} is ACTIVE."
    else:
        status = WAITLISTED
        msg = f"No copies free. You are on the waitlist for '{book['title']}' ({res_id})."
    reservations.append({
        "res_id": res_id, "username": username, "book_id": book["book_id"],
        "date": date.today().isoformat(), "status": status,
    })
    save_books(books)
    save_reservations(reservations)
    return True, msg


def cancel_reservation(username, res_id, books, reservations):
    """
    Cancel one of the member's own reservations. If it held a copy, the copy
    is given to the first person on the waitlist (oldest first) or returned
    to the shelf. Returns (True, message) or (False, reason).
    """
    target = None
    for r in reservations:
        if r["res_id"].lower() == res_id.strip().lower() and r["username"] == username \
                and r["status"] in (ACTIVE, WAITLISTED):
            target = r
            break
    if target is None:
        return False, "No cancellable reservation with that id."

    was_active = target["status"] == ACTIVE
    target["status"] = CANCELLED
    msg = f"Reservation {target['res_id']} cancelled."

    if was_active:
        book = find_book(books, target["book_id"])
        next_in_line = None
        for r in reservations:                    # list is in date order
            if r["book_id"] == target["book_id"] and r["status"] == WAITLISTED:
                next_in_line = r
                break
        if next_in_line:
            next_in_line["status"] = ACTIVE
            msg += f" The copy was passed to {next_in_line['username']} (waitlist)."
        elif book:
            book["copies_available"] += 1
    save_books(books)
    save_reservations(reservations)
    return True, msg


def mark_collected(res_id, reservations):
    """Librarian marks an ACTIVE reservation as collected by the member."""
    for r in reservations:
        if r["res_id"].lower() == res_id.strip().lower() and r["status"] == ACTIVE:
            r["status"] = COLLECTED
            save_reservations(reservations)
            return True, f"{r['res_id']} marked as collected."
    return False, "No ACTIVE reservation with that id."


def display_reservations(reservations, books):
    """Print reservations with book titles."""
    if not reservations:
        print("  No reservations to show.")
        return
    print(f"  {'Res':<7}{'User':<12}{'Book':<30}{'Date':<12}{'Status'}")
    print("  " + "-" * 72)
    for r in reservations:
        book = find_book(books, r["book_id"])
        title = book["title"] if book else r["book_id"]
        print(f"  {r['res_id']:<7}{r['username']:<12}{title[:28]:<30}{r['date']:<12}{r['status']}")


# --------------------------------------------------------------------------
# Reports
# --------------------------------------------------------------------------
def generate_report(books, reservations, users, save_to=None):
    """
    Build a text summary of the library: stock, reservation counts, most
    reserved titles and members with the most active reservations.
    Optionally writes it to `save_to`. Returns the report as a string.
    """
    total_copies = sum(b["copies_total"] for b in books)
    available = sum(b["copies_available"] for b in books)
    counts = {ACTIVE: 0, WAITLISTED: 0, CANCELLED: 0, COLLECTED: 0}
    per_book, per_member = {}, {}
    for r in reservations:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
        per_book[r["book_id"]] = per_book.get(r["book_id"], 0) + 1
        if r["status"] in (ACTIVE, WAITLISTED):
            per_member[r["username"]] = per_member.get(r["username"], 0) + 1

    lines = [
        "=" * 50,
        f"LIBRARY REPORT  -  {date.today().isoformat()}",
        "=" * 50,
        f"Titles in catalogue : {len(books)}",
        f"Total copies        : {total_copies}",
        f"Copies on shelf     : {available}",
        f"Members registered  : {sum(1 for u in users.values() if u['role'] == 'member')}",
        "",
        "Reservations by status:",
    ]
    for status, n in counts.items():
        lines.append(f"  {status:<11}: {n}")

    lines.append("")
    lines.append("Most reserved titles:")
    ranked = sorted(per_book.items(), key=lambda kv: kv[1], reverse=True)[:3]
    if not ranked:
        lines.append("  (none yet)")
    for book_id, n in ranked:
        book = find_book(books, book_id)
        lines.append(f"  {book['title'] if book else book_id}: {n}")

    lines.append("")
    lines.append("Members with open reservations:")
    if not per_member:
        lines.append("  (none)")
    for name, n in sorted(per_member.items(), key=lambda kv: kv[1], reverse=True):
        lines.append(f"  {name}: {n}")

    lines.append("")
    lines.append("Books with no copies available:")
    out = [b["title"] for b in books if b["copies_available"] == 0]
    lines.extend([f"  {t}" for t in out] or ["  (none)"])
    report = "\n".join(lines)

    if save_to:
        try:
            with open(save_to, "w", encoding="utf-8") as f:
                f.write(report + "\n")
        except (PermissionError, OSError) as err:
            print(f"[error] Could not save report: {err}")
    return report


# --------------------------------------------------------------------------
# Menus (interactive loops)
# --------------------------------------------------------------------------
def member_menu(username, users, books, reservations):
    """Menu loop for a logged-in member. Returns when they log out."""
    while True:
        print(f"\n--- Member Menu ({users[username]['name']}) ---")
        print("1. Browse all books\n2. Search books\n3. Reserve a book")
        print("4. My reservations\n5. Cancel a reservation\n0. Log out")
        choice = read_int("Choose: ", 0, 5)
        if choice == 0:
            print("Logged out.")
            return
        elif choice == 1:
            display_books(books)
        elif choice == 2:
            kw = read_text("Keyword (title/author/id, blank = all): ", allow_empty=True)
            cat = read_text("Category (blank = any): ", allow_empty=True)
            display_books(search_record(books, kw, cat))
        elif choice == 3:
            display_books(books)
            ok, msg = reserve_book(username, read_text("Book id to reserve: "), books, reservations)
            print(("  " if ok else "  ! ") + msg)
        elif choice == 4:
            display_reservations(member_reservations(
                reservations, username, (ACTIVE, WAITLISTED, COLLECTED, CANCELLED)), books)
        elif choice == 5:
            display_reservations(member_reservations(reservations, username), books)
            ok, msg = cancel_reservation(username, read_text("Reservation id to cancel: "),
                                         books, reservations)
            print(("  " if ok else "  ! ") + msg)


def admin_menu(username, users, books, reservations):
    """Menu loop for a librarian. Returns when they log out."""
    while True:
        print("\n--- Librarian Menu ---")
        print("1. View catalogue\n2. Add a book\n3. View all reservations")
        print("4. Mark reservation collected\n5. Generate report\n0. Log out")
        choice = read_int("Choose: ", 0, 5)
        if choice == 0:
            print("Logged out.")
            return
        elif choice == 1:
            display_books(books)
        elif choice == 2:
            title = read_text("Title: ")
            author = read_text("Author: ")
            cat = read_text("Category: ", allow_empty=True)
            copies = read_int("Number of copies: ", 1)
            ok, result = add_record(books, title, author, cat, copies)
            print("  Added " + result["book_id"] if ok else "  ! " + result)
        elif choice == 3:
            display_reservations(reservations, books)
        elif choice == 4:
            ok, msg = mark_collected(read_text("Reservation id: "), reservations)
            print(("  " if ok else "  ! ") + msg)
        elif choice == 5:
            print(generate_report(books, reservations, users,
                                  save_to=_path("report.txt")))
            print(f"(saved to {_path('report.txt')})")


def main():
    """Entry point: load data, then run the main loop until the user exits."""
    users = initialise_data()
    books = load_books()
    reservations = load_reservations()
    print("=" * 50)
    print(" LIBRARY BOOK RESERVATION PORTAL")
    print("=" * 50)
    try:
        while True:                                   # main portal loop
            print("\n1. Log in\n2. Register as member\n0. Exit")
            choice = read_int("Choose: ", 0, 2)
            if choice == 0:
                break
            if choice == 2:
                ok, msg = register_user(read_text("Username: "), read_text("Full name: "),
                                        read_text("Password: "), users)
                print(("  " if ok else "  ! ") + msg)
                continue
            user = user_login(read_text("Username: "), read_text("Password: "), users)
            if user is None:
                print("  ! Invalid username or password.")
            elif users[user]["role"] == "admin":
                admin_menu(user, users, books, reservations)
            else:
                member_menu(user, users, books, reservations)
    except (KeyboardInterrupt, EOFError):
        print("\nInterrupted - exiting safely.")
    finally:
        save_books(books)
        save_reservations(reservations)
        save_users(users)
        print("All data saved. Goodbye!")


if __name__ == "__main__":
    main()
