Add high-resolution screenshots here:
1. GitHub repo showing commit history
2. Notebook with successful execution outputs
3. data/ files (books.csv, reservations.csv, users.json) created or modified
4. Frontend (optional, not applicable - terminal menu used)
