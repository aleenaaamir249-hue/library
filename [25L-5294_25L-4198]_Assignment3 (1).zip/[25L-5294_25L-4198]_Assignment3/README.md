# Library Book Reservation Portal

Assignment 3 - End-to-End Portal Design (Python)

A console-based portal where **members** search a library catalogue and reserve books
(with an automatic **waitlist** when every copy is taken) and **librarians** manage the
catalogue, mark reservations collected and generate reports. Built with core Python only
(no third-party packages).

## Features

- Member registration and login (passwords stored as salted SHA-256 hashes)
- Browse and search books by title, author, ID or category
- Reserve a book: a copy is held, or the member joins the waitlist
- Limit of 3 open reservations per member, no duplicate reservations
- Cancelling a held reservation passes the copy to the first person on the waitlist
- Librarian menu: add books, view all reservations, mark collected, generate report
- All data persists between runs (CSV and JSON files)
- Invalid input and file problems are handled without crashing

## Requirements

Python 3.8 or newer. Nothing to install.

## Run it

```bash
python library_portal.py
```

On the first run the portal creates a `data/` folder with a sample catalogue and a default
librarian account:

| Role | Username | Password |
|---|---|---|
| Librarian | `admin` | `admin123` |

Members register themselves from the start menu. Run `Library_Reservation_Portal.ipynb`
(Kernel -> Restart & Run All) to see the same code with sample test runs.

## Project structure

```
library_portal.py                  main program (functions + menus)
Library_Reservation_Portal.ipynb   runnable notebook with demos and test runs
data/                              created automatically on first run
  books.csv                        catalogue and copy counts
  reservations.csv                 reservations (ACTIVE / WAITLISTED / CANCELLED / COLLECTED)
  users.json                       accounts with salted password hashes
  report.txt                       written when the librarian generates a report
```

## Main functions

| Function | Purpose |
|---|---|
| `user_login(username, password, users)` | Verify credentials, return the username or `None` |
| `register_user(...)` | Create a member account with validation |
| `add_record(books, title, author, category, copies)` | Add a book to the catalogue |
| `search_record(books, keyword, category)` | Filter books by keyword and category |
| `reserve_book(username, book_id, books, reservations)` | Hold a copy or join the waitlist |
| `cancel_reservation(...)` | Cancel and promote the next waitlisted member |
| `mark_collected(res_id, reservations)` | Librarian marks a pick-up |
| `generate_report(books, reservations, users, save_to)` | Text summary of stock and reservations |
| `main()` | `while True` loop that runs until the user exits |

## Error handling

`FileNotFoundError` (file recreated), `PermissionError`, corrupted CSV/JSON, `ValueError`
for non-numeric input, and `Ctrl+C` / end-of-input are all caught. A `finally` block saves
all data on exit.

## Team

- Aleena Aamir (25L-5294)
- Mahnoor Imran (25L-4198)
